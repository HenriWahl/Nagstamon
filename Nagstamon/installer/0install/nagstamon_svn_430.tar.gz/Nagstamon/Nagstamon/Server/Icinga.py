# encoding: utf-8

from Nagstamon.Server.Generic import GenericServer


class IcingaServer(GenericServer):    
    """
        object of Incinga server
    """   
    TYPE = 'Icinga'
